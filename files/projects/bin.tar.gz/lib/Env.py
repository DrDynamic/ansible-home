
class Env:
    _lines=None
    def load(self, path):
        with open(path, 'r') as file:
            self._lines = file.readlines()
        return self

    def get(self, key):
        for line in self._lines:
            if line.strip().startswith('#') or line.strip() == "":
                continue
            if line.split("=",1)[0] == key:
                return line.split("=", 1)[1]

    def set(self, key, value):
        value_set = False
        for index, line in enumerate(self._lines):
            if line.strip() == "":
                continue
            elif line.strip().startswith('#'):
                if line.strip()[1:].split("=",1)[0] == key:
                    self._lines[index] = "%s=%s" % (key, value)
                    value_set = True
            elif line.split("=", 1)[0] == key:
                self._lines[index] = "%s=%s" % (key, value)
                value_set = True
        if not value_set:
            self._lines.append("%s=%s" % (key, value))

    def get_keys(self):
        return list(
                map(lambda line: line.split("=",1)[0], 
                    filter(lambda line: not line.strip().startswith('#') 
                        and not line.strip() == "", self._lines)))

    def merge(self, env):
        keys = env.get_keys()
        for key in keys:
            self.set(key, env.get(key))

    def __str__(self):
        return "".join(self._lines)

